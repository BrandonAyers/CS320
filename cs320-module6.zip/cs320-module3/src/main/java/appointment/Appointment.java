package appointment;

import java.time.LocalDate;

public record Appointment(
        String id,
        LocalDate date,
        String description
) {
    public Appointment {
        validateId(id);
        validateDate(date);
        validateDescription(description);
    }

    //Checking to see that the ID is less than 10 characters and not null or empty.
    static protected boolean validateId(final String id) {
        if(id == null || id.length() > 10 || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID must be a String no more than 10 characters in length");
        }
        return true;
    }

    //Checking to see if the date is in the past
    static protected boolean validateDate(final LocalDate date) {
        if(date == null || date.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Date must be today or in the future");
        }
        return true;
    }

    //Checking to see that the description is less than 50 characters and not null or empty.
    static protected boolean validateDescription(final String description) {
        if(description == null || description.length() > 50 || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must be a String no more than 50 characters in length");
        }
        return true;
    }
}
