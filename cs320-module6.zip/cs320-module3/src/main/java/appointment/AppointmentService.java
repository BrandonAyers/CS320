package appointment;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AppointmentService {
    protected static AppointmentService INSTANCE;

    protected Map<String, Appointment> repository;

    private AppointmentService() {repository = new ConcurrentHashMap<>();}

    public static synchronized AppointmentService getInstance() {
        if(INSTANCE == null){
            INSTANCE = new AppointmentService();
        }
        return INSTANCE;
    }

    //add appointment
    public void add(final Appointment appointment) {
        if(repository.containsKey(appointment.id())) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] already exists"));
        }
        repository.put(appointment.id(), appointment);
    }

    //remove appointment
    public void remove(String id) {
        if(!repository.containsKey(id)) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] doesn't exist"));
        }
        repository.remove(id);
    }
}
