package people;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ContactService {
    protected static ContactService INSTANCE;
    protected Map<String, Contact> repository;

    private ContactService() {
        repository = new ConcurrentHashMap<>();
    }

    public static synchronized ContactService getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new ContactService();
        }
        return INSTANCE;
    }

    public void add(final Contact contact) {
        //Check if ID exist
        //I think [%s] might need changed to {contact.id()} to output the id entered
        if(repository.containsKey(contact.id())) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] already exists"));
        }
        repository.put(contact.id(), contact);
    }

    public void remove(String id) {
        //Check if ID exist
        if(!repository.containsKey(id)) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] doesn't exist"));
        }
        repository.remove(id);
    }

    public void modify(String id, final Contact contact){
        //Check if ID exist
        if(!repository.containsKey(id)) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] doesn't exist"));
        }
        //This verifies the ID entered to modify matches the ID entered to modify ensuring it's not changeable
        else if(!contact.id().equals(id)){
            throw new IllegalArgumentException("ID entered must match modified ID");
        }
        repository.put(id, contact);
    }

}
