package people;

public record Contact(
        String id,
        String firstName,
        String lastName,
        String phoneNumber,
        String address
) {
    public Contact {
        validateId(id);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhoneNumber(phoneNumber);
        validateAddress(address);
    }

    static protected boolean validateId(final String id) {
        //Check for null and length
        if(id == null || id.length() > 10) {
            throw new IllegalArgumentException("ID must be a String no more than 10 characters in length");
        }
        return true;
    }

    static protected boolean validateFirstName(final String firstName) {
        //Check for null and length
        if(firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First Name must be a String no more than 10 characters in length");
        }
        return true;
    }

    static protected boolean validateLastName(final String lastName) {
        //Check for null and length
        if(lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last Name must be a String no more than 10 characters in length");
        }
        return true;
    }

    static protected boolean validatePhoneNumber(final String phoneNumber) {
        //Check for null and length
        if(phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Phone Number must be 10 characters in length");
        }
        return true;
    }

    static protected boolean validateAddress(final String address) {
        //Check for null and length
        if(address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address must be a String no more than 30 characters in length");
        }
        return true;
    }
}
