package task;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TaskService {

    protected static TaskService INSTANCE;

    protected Map<String, Task> repository;

    private TaskService() { repository = new ConcurrentHashMap<>(); }

    public static synchronized TaskService getInstance() {
        if(INSTANCE == null){
            INSTANCE = new TaskService();
        }
        return INSTANCE;
    }

    //add Task
    public void add(final Task task) {
        //Check if ID exist
        if(repository.containsKey(task.id())) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] already exists"));
        }
        //Add the Task if it doesn't
        repository.put(task.id(), task);
    }

    //Remove Task
    public void remove(String id) {
        //Check if ID exist
        if(!repository.containsKey(id)) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] doesn't exist"));
        }
        //Delete ID if it exists
        repository.remove(id);
    }

    //Modify Task
    public void modify(String id, final Task task){
        //Check if ID exists
        if(!repository.containsKey(id)) {
            throw new IllegalArgumentException(String.format("A contact with the ID [%s] doesn't exist"));
        }

        //Verified the ID being modified is the same being entered. Ensures ID cannot be changed
        else if(!task.id().equals(id)){
            throw new IllegalArgumentException("ID entered must match modified ID");
        }
        //Update the task with new information
        repository.put(id, task);
    }
}
