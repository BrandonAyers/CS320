package task;

public record Task(
        String id,
        String name,
        String description
) {
    public Task {
        validateId(id);
        validateName(name);
        validateDescription(description);
    }

    static protected boolean validateId(final String id) {
        //Check for null, length, and blank
        if(id == null || id.length() > 10 || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID must be a String no more than 10 characters in length");
        }
        return true;
    }

    static protected boolean validateName(final String name) {
        //Check for null, length, and blank
        if(name == null || name.length() > 20 || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name must be a String no more than 20 characters in length");
        }
        return true;
    }

    static protected boolean validateDescription(final String description) {
        //Check for null, length, and blank
        if(description == null || description.length() > 50 || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description must be a String no more than 30 characters in length");
        }
        return true;
    }


}
