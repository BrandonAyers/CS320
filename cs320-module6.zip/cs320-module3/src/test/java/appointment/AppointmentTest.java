package appointment;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AppointmentTest {

    //Id Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidateId_Valid() {
        assertTrue(Appointment.validateId("1234567890"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateId_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateId(null));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidateId_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateId("012345678901"));
    }

    @Test
        //Testing to see if a blank input throws error
    void testValidateId_Blank() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateId("         "));
    }

    //Date Testing

    @Test
        //Testing using valid day one day in the future
    void testValidDate_Valid() {assertTrue(Appointment.validateDate(LocalDate.now().plusDays(1)));}

    @Test
        //Testing using valid same day
    void testValidDate_ValidSameDay() {assertTrue(Appointment.validateDate(LocalDate.now()));}

    @Test
        //Testing using invalid day one day in the past
    void testValidDate_BeforeToday() {
        assertThrows(IllegalArgumentException.class, () -> Appointment.validateDate(LocalDate.now().minusDays(1)));}

    //Description Testing

    @Test
        //Testing to see if an input under 50 works
    void testValidateDescription_Valid() {
        assertTrue(Appointment.validateDescription("The task for today is to go to the gym then cook."));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateDescription_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateDescription(null));
    }

    @Test
        //Testing to see if an input over 50 throws error
    void testValidateDescription_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateDescription("The task for today is to go to the gym. Then go home to do college before cooking."));
    }

    @Test
        //Testing to see if a blank input throws and error
    void testValidateDescription_Blank() {
        assertThrows(IllegalArgumentException.class,
                () -> Appointment.validateDescription("         "));
    }
}
