package appointment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    //Clears the HashMap
    void init() {
        AppointmentService.INSTANCE = null;
        service = AppointmentService.getInstance();
    }

    @Test
        //Checking to see if you can add an appointment
    void add_Success() {
        final Appointment appointment = new Appointment("1", LocalDate.now().plusDays(1), "Go to the gym.");
        service.add(appointment);
        assertTrue(service.repository.containsKey("1"));
    }

    //Checking to see if an error is thrown when trying to add an already existing id
    @Test
    void add_ExistingId() {
        final Appointment appointment = new Appointment("1", LocalDate.now().plusDays(1), "Go to the gym.");
        service.add(appointment);
        assertThrows(IllegalArgumentException.class, () -> service.add(appointment));
    }

    //Checking to see if removing id works
    @Test
    void removeExistingId() {
        final Appointment appointment = new Appointment("1",LocalDate.now().plusDays(1), "Go to the gym.");
        service.add(appointment);
        service.remove("1");
        assertFalse(service.repository.containsKey("1"));
    }

    //Checking to see if error is thrown when removing a non-existent id
    @Test
    void removeNotExistingId() {
        assertThrows(IllegalArgumentException.class, () -> service.remove("1"));
    }

}
