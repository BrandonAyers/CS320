package people;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    //Id Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidateId_Valid() {
        assertTrue(Contact.validateId("1234567890"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateId_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateId(null));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidateId_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateFirstName("012345678901"));
    }

    //First Name Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidateFirstName_Valid() {
        assertTrue(Contact.validateFirstName("Bob"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateFirstName_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateFirstName(null));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidateFirstName_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateFirstName("012345678901234"));
    }

    //Last Name Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidateLastName_Valid() {
        assertTrue(Contact.validateLastName("Bob"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateLastName_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateLastName(null));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidateLastName_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateLastName("012345678901234"));
    }


    //Phone Number Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidatePhoneNumber_Valid() {
        assertTrue(Contact.validatePhoneNumber("1234567890"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidatePhoneNumber_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validatePhoneNumber(null));
    }

    @Test
        //Testing to see if an input under 10 throws error
    void testValidatePhoneNumber_TooShort() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validatePhoneNumber("0"));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidatePhoneNumber_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validatePhoneNumber("012345678901234"));
    }

    //Address Testing

    @Test
        //Testing to see if an input under 30 works
    void testValidateAddress_Valid() {
        assertTrue(Contact.validateAddress("300 snhu circle"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateAddress_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateAddress(null));
    }

    @Test
        //Testing to see if an input over 30 throws error
    void testValidateAddress_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Contact.validateAddress("300 snhu circle, southern newhamshire"));
    }
}
