package task;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    //Clears the HashMap
    void init() {
        TaskService.INSTANCE = null;
        service = TaskService.getInstance();
    }

    @Test
        //Checking to see if you can add a contact
    void add_Success() {
        final Task task = new Task("1", "Full Name", "Go to the gym.");
        service.add(task);
        assertTrue(service.repository.containsKey("1"));
    }

    //Checking to see if an error is thrown when trying to add an already existing id
    @Test
    void add_ExistingId() {
        final Task task = new Task("1", "Full Name", "Go to the gym.");
        service.add(task);
        assertThrows(IllegalArgumentException.class, () -> service.add(task));
    }

    //Checking to see if removing id works
    @Test
    void removeExistingId() {
        final Task task = new Task("1", "Full Name", "Go to the gym.");
        service.add(task);
        service.remove("1");
        assertFalse(service.repository.containsKey("1"));
    }

    //Checking to see if error is thrown when removing a non-existent id
    @Test
    void removeNotExistingId() {
        assertThrows(IllegalArgumentException.class, () -> service.remove("1"));
    }

    //Checking to see if modify works when being changed
    @Test
    void modifyExistingId() {
        final Task task = new Task("1", "Full Name", "Go to the gym.");
        service.add(task);
        final Task temp = new Task("1", "Partial Name", "Go to the store.");
        service.modify("1", temp);
        assertSame(service.repository.get("1"), temp);
    }

    //Checking to see if error is thrown when modifying ID that doesn't exist
    @Test
    void modifyNonExistingId() {
        final Task task = new Task("1", "First Name", "Last Name");
        assertThrows(IllegalArgumentException.class, () -> service.modify("1", task));
    }

    //Checking to see if modified ID matches entered ID making ID immutable
    //The ID is technically still able to be changed but this would prevent the change by throwing an error
    //I would make the code take the initial ID to modify automatically insert it into contact to ensure the end user wouldn't have to enter it twice
    //Might be a better way to do this!!!
    //Only took 1 java coding class
    @Test
    void modifyExistingIdMatch() {
        final Task task = new Task("1", "First Name", "Go to the gym.");
        service.add(task);
        assertThrows(IllegalArgumentException.class, () -> service.modify("2", task));
    }


}
