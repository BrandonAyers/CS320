package task;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TaskTest {

    //Id Testing

    @Test
        //Testing to see if an input under 10 works
    void testValidateId_Valid() {
        assertTrue(Task.validateId("1234567890"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateId_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateId(null));
    }

    @Test
        //Testing to see if an input over 10 throws error
    void testValidateId_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateId("012345678901"));
    }

    @Test
        //Testing to see if a blank input throws error
    void testValidateId_Blank() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateId("         "));
    }

    //Name Testing

    @Test
        //Testing to see if an input under 20 works
    void testValidateName_Valid() {
        assertTrue(Task.validateName("Brandon Ayers"));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateName_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateName(null));
    }

    @Test
        //Testing to see if an input over 20 throws error
    void testValidateName_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateName("Brandon Daniel Ayers Sr"));
    }

    @Test
        //Testing to see if a blank input throws and error
    void testValidateName_Blank() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateName("         "));
    }

    //Description Testing

    @Test
        //Testing to see if an input under 50 works
    void testValidateDescription_Valid() {
        assertTrue(Task.validateDescription("The task for today is to go to the gym then cook."));
    }

    @Test
        //Testing to see if a null input throws error
    void testValidateDescription_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateDescription(null));
    }

    @Test
        //Testing to see if an input over 50 throws error
    void testValidateDescription_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateDescription("The task for today is to go to the gym. Then go home to do college before cooking."));
    }

    @Test
        //Testing to see if a blank input throws and error
    void testValidateDescription_Blank() {
        assertThrows(IllegalArgumentException.class,
                () -> Task.validateDescription("         "));
    }


}
